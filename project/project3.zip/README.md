#Neighbourhood Map project
  ##This project uses a Google API to load map.Markers represent the places to visit which is also shown as a list view which can be selected select that particular map.

  ## to run project
  *1.Download the zip file  on to your localmachine.
  *2.extract the files.
  *3.Open the **index._html_file, with google browser.
  *click on any location ,corresponding markers will bounce with infowindows.
  *alternatively, click on any markers to display the same along with wikipedia data.

  ## Resources
  _jQuery_
  _knockout_
  _CSS_
  _html_

  ## Detailing of project:
   *It shows markers in map
   *shows list elements
   *when a list element is clicked corresponding marker bounces.
   *effective filtering is applied for the list elements.
   *when map marker is clicked corresponding info-window pops up.
   *for the info-window, street view is applied.
   *error handling is provided, when either there's a loading problem with google maps or wikipedia.
   *responsive site
